game.import("extension",function(lib,game,ui,get,ai,_status){return {name:"无名扩展",content:function(config,pack){
    
},precontent:function(){
    
},help:{},config:{},package:{
    character:{
        character:{
            "胡桃":["female","shen",3,["蝶引","安神"],["des:璃月“往生堂”第七十七代堂主，掌控着璃月葬仪事务的重要人物"]],
            "行秋":["male","shen",3,["行侠","惩恶","不可响应"],["des:璃月港飞云商会的二少爷，自幼便以勤奋好学、待人礼貌闻名，也不乏行侠仗义之举"]],
            "芙宁娜":["female","shen",3,["nzry_guxin"],["des:芙芙"]],
            "刻晴":["female","shen",3,["yuhenggai","leiligai"],["des:璃月七星中的玉衡星，  负责管理土地与建设的工作"]],
            "莱依拉":["female","shen",3,["shuangsheng","xmrumeng","mengxing"],["des:专攻理论星相学的梨多梵谛学院学生，时常梦游"]],
            "重云":["male","shen",4,["lyfangshi"],["des:以璃月为中心，四处进行驱邪活动的云游方士"]],
        },
        translate:{
            "胡桃":"胡桃",
            "行秋":"行秋",
            "芙宁娜":"芙宁娜",
            "刻晴":"刻晴",
            "莱依拉":"莱依拉",
            "重云":"重云",
        },
    },
    card:{
        card:{
        },
        translate:{
        },
        list:[],
    },
    skill:{
        skill:{
            "蝶引":{
                trigger:{
                    player:["damageEnd","phaseDiscardBegin"],
                },
                frequent:true,
                locked:false,
                notemp:true,
                filter:function(event,player){
        return true;
    },
                content:function(){
        "step 0"
        event.count=trigger.num||1;
        "step 1"
        event.count--;
        player.draw(2);
        "step 2"
        // if(player.countCards('he',"red")>0){
        if(player.countCards('he',{color:"red"})>0){
            player.chooseCard(1,'he','将一张红色牌置于武将牌上作为“舞”',true,{color:"red"});
        }
        else{
            event.goto(4);
        }
        "step 3"
        if(result.cards&&result.cards.length){
            player.addToExpansion(result.cards,player,'give').gaintag.add('蝶引');
        }
        "step 4"
        if(event.count>0&&player.hasSkill(event.name)&&!get.is.blocked(event.name,player)){
            player.chooseBool(get.prompt2('蝶引')).set('frequentSkill',event.name);
        }
        else event.finish();
        "step 5"
        if(result.bool){
            player.logSkill('蝶引');
            event.goto(1);
        }
    },
                marktext:"舞",
                intro:{
                    content:"expansion",
                    markcount:"expansion",
                },
                mod:{
                },
                onremove:function(player,skill){
        var cards=player.getExpansions('quanji');
        if(cards.length) player.loseToDiscardpile(cards);
    },
                ai:{
                    maixie:true,
                    "maixie_hp":true,
                    threaten:0.8,
                },
                "_priority":0,
            },
            "安神":{
                trigger:{
                    global:"phaseUseBegin",
                },
                direct:true,
                filter:function (event, player) {
        if (player == event.player)
            return false;
        return player.hp <= player.getExpansions('蝶引').length;
    },
                logTarget:"player",
                content:function () {
        'step 0'
        player.chooseButton(
            ui.create.dialog('安神', player.getExpansions('蝶引'), 'hidden'), function (links, button) {
                return true;
            }
        );

        'step 1'
        cardanshen = result.links;
        // if (player.canUse({name: 'sha', isCard: true, nature: 'fire',}, event.player, false))
        player.useCard({name: 'sha', isCard: true, nature: 'fire'}, cardanshen, trigger.player, false);
        'step 2'
        if (player.hasHistory('sourceDamage', function (evt) {
            var card = evt.card;
            if (!card || card.name != 'sha') return false;
            var evtx = evt.getParent('useCard');
            return evtx.card == card && evtx.getParent() == event;
        })) {
            player.recover();
        }
    },
                "_priority":0,
            },
            "行侠":{
                audio:"ext:无名扩展:2",
                trigger:{
                    global:"phaseJieshuBegin",
                },
                direct:true,
                filter:function(event,player){
        return player!=event.player&&event.player.getHistory('sourceDamage').length>0&&event.player.isIn()&&(player.countCards('h')>0||player.canUse('guohe',event.player));
    },
                content:function(){
        'step 0'
        var target=trigger.player;
        var choiceList=['将一张手牌当做【杀】对其使用','将一张手牌当做【过河拆桥】对其使用'];
        var bool=false,hs=player.getCards('h');
        for(var i of hs){
            if(game.checkMod(i,player,'unchanged','cardEnabled2',player)!==false&&player.canUse(get.autoViewAs({name:'sha'},[i]),target,false)){
                bool=true;
                break;
            }
        }
        var choices=[];
        if(bool) choices.push('选项一');
        else choiceList[0]='<span style="opacity:0.5">'+choiceList[0]+'</span>';
        if(player.canUse('guohe',target)) choices.push('选项二');
        else choiceList[1]='<span style="opacity:0.5">'+choiceList[1]+'</span>';
        choices.push('cancel2');
        player.chooseControl(choices).set('choiceList',choiceList).set('prompt',get.prompt('行侠',target)).set('ai',function(){
            var choices=_status.event.controls;
            var eff1=0,eff2=0;
            var player=_status.event.player,target=_status.event.getTrigger().player;
            if(choices.contains('选项一')) eff1=get.effect(target,{name:'sha'},player,player);
            if(choices.contains('选项二')) eff2=get.effect(target,{name:'guohe'},player,player);
            if(eff1>0&&(player.hasSkill('xsqianxin')&&player.isDamaged()||eff1>eff2)) return '选项一';
            if(eff2>0) return '选项二';
            return 'cancel2';
        });
        'step 1'
        if(result.control!='cancel2'){
            if(result.control=='选项一'){
                player.chooseCard('h',true,function(card,player){
                    if(!game.checkMod(card,player,'unchanged','cardEnabled2',player)) return false;
                    return player.canUse(get.autoViewAs({name:'sha'},[card]),_status.event.getTrigger().player,false);
                },'选择一张手牌当做【杀】对'+get.translation(trigger.player)+'使用').set('ai',function(card){
                    var player=_status.event.player;
                    return get.effect(_status.event.getTrigger().player,get.autoViewAs({name:'sha'},[card]),player,player)/Math.max(1,get.value(card));
                });
            }
            else{
                player.chooseCard('h',true,'选择一张手牌当做【过河拆桥】对'+get.translation(trigger.player)+'使用');
                event.goto(3);
            }
        }
        else event.finish();
        'step 2'
        if(result.bool){
            player.useCard({name:'sha'},result.cards,'行侠',trigger.player,false);
        }
        event.finish();
        'step 3'
        player.useCard({name:'guohe'},result.cards,trigger.player,'行侠',false);
    },
                "_priority":0,
            },
            "惩恶":{
                trigger:{
                    player:"damageEnd",
                },
                logTarget:"source",
                filter:function(event,player){
        return (event.source&&event.source.countGainableCards(player,event.source!=player?'he':'e')&&event.num>0);
    },
                content:function(){
        'step 0'
        event.count=trigger.num;
        'step 1'
        event.count--;
        player.choosePlayerCard(trigger.source,'h',true);
        'step 2'
        cardchenge=result.cards
        player.showCards(result.cards,get.translation(player)+'对'+get.translation(trigger.source)+'发动了【惩恶】');
        'step 3'
        player.gain(cardchenge,trigger.source);
        'step 4'
        player.chooseTarget(true).set('createDialog',['请选择一名角色获得这张牌',cardchenge])
        'step 5'
        player.give(cardchenge,result.targets[0]);
        'step 6'
        if(result.bool&&event.count>0&&trigger.source.countGainableCards(player,trigger.source!=player?'he':'e')>0&&player.hasSkill(event.name)) 
            event.goto(1);
    },
                "_priority":0,
            },
            "nzry_guxin":{
                mark:true,
                locked:false,
                zhuanhuanji:true,
                marktext:"☯",
                intro:{
                    content:function (storage, player, skill) {
             if (player.storage.nzry_guxin == true) return '出牌阶段限一次,你可以失去一点体力，然后展示牌堆顶的三张牌，你获得其中一张，根据其类型获得效果:基本:此牌伤害/回复量+1。锦囊:此牌无距离限制且不可被响应 装备:使用此牌后移动场上的一张牌。';
             return '出牌阶段限一次，你可以回复一点体力(若体力满则改为摸两张牌)并弃一张牌，本回合内你使用与该牌颜色相同的牌时摸一张牌';
             },
                },
                init:function(player){//初始化，获得这个技能时执行的内容
             player.storage.nzry_guxin=true;

         },
                group:["nzry_guxin_1","nzry_guxin_2"],
                subSkill:{
                    "1":{
                        prompt:"出牌阶段限一次，你可以回复一点体力(若体力满则改为摸两张牌)并弃一张牌，本回合内你使用与该牌颜色相同的牌时摸一张牌",
                        enable:"phaseUse",
                        usable:1,
                        filter:function (event, player) {
                 return player.countCards('he') > 0 && player.storage.nzry_guxin != true;
             },
                        content:function () {
                 'step 0'
                 player.changeZhuanhuanji('nzry_guxin');
                 if(player.hp==player.maxHp){
                     player.draw(2);
                 }else player.recover();
                 'step 1'
                 if(player.countCards('he')>0)
                     player.chooseToDiscard('he',true);
                 else event.finish();
                 'step 2'
                 player.storage.nzry_guxin1=[];
                 player.storage.nzry_guxin1.add(get.color(result.cards,player));
                 player.markSkill('孤心');
                 player.addTempSkill('nzry_guxin_draw');


             },
                        sub:true,
                        "_priority":0,
                    },
                    "2":{
                        enable:"phaseUse",
                        usable:1,
                        filter:function (event, player) {
                 return player.hp > 1 &&  player.storage.nzry_guxin == true;
             },
                        "prompt2":"出牌阶段限一次,你可以失去一点体力，然后展示牌堆顶的三张牌，你获得其中一张，根据其类型获得效果:基本:此牌伤害/回复量+1。锦囊:此牌无距离限制且不可被响应 装备:使用此牌后移动场上的一张牌。",
                        content:function () {
                 "step 0"
                 player.changeZhuanhuanji('nzry_guxin');
                 player.loseHp();
                     "step 1"
                     event.cards=get.cards(3);
                     event.videoId=lib.status.videoId++;
                     game.broadcastAll(function(player,id,cards){
                         var str;
                         if(player==game.me&&!_status.auto){
                             str='【孤心】选择获得其中一张牌';
                         }
                         else{
                             str='孤心';
                         }
                         var dialog=ui.create.dialog(str,cards);
                         dialog.videoId=id;
                     },player,event.videoId,event.cards);
                     event.time=get.utc();
                     game.addVideo('showCards',player,['孤心',get.cardsInfo(event.cards)]);
                     game.addVideo('delay',null,2);
                     "step 2"
                     var next=player.chooseButton([1,1],true);
                     next.set('dialog',event.videoId);

                     "step 3"
                     if(result.bool&&result.links){
                         var cards2=[];
                         for(var i=0;i<result.links.length;i++){
                             cards2.push(result.links[i]);
                             cards.remove(result.links[i]);
                         }
                         game.cardsDiscard(cards);
                         event.card2=cards2[0];
                     }
                     var time=1000-(get.utc()-event.time);
                     if(time>0){
                         game.delay(0,time);
                     }
                     "step 4"
                     game.broadcastAll('closeDialog',event.videoId);
                     var card2=event.card2;

                     // player.addTempSkill('nzry_shenshi2');
                     // player.markAuto('nzry_shenshi2',[get.type2(card2,player)]);
                     if(get.type(card2)=='basic'){
                         player.gain(card2,'gain2').gaintag=['nzry_guxin_tag1'];

                          player.addTempSkill('nzry_guxin_tag1');
                     }
                     if(get.type(card2)=='trick') {
                         player.gain(card2,'gain2').gaintag=['nzry_guxin_tag2'];

                         player.addTempSkill('nzry_guxin_tag2');
                     }
                     if(get.type(card2)=='equip') {
                         player.gain(card2,'gain2').gaintag=['nzry_guxin_tag3'];

                         player.addTempSkill('nzry_guxin_tag3');
                     }
                     player.storage.nzry_guxin2=card2;

                 },
                        sub:true,
                        "_priority":0,
                    },
                    "tag1":{
                        trigger:{
                            player:"useCard",
                        },
                        filter:function(event,player){
                 return event.card.gaintag&&event.card.gaintag.contains('nzry_guxin_tag1');

             },
                        content:function(){
                 player.draw();
             },
                        onremove:(player,skill)=>player.removeGaintag(skill),
                        sub:true,
                        "_priority":0,
                    },
                    "tag2":{
                        trigger:{
                            player:"useCard",
                        },
                        filter:function(event,player){
                 // return event.card==player.storage.nzry_guxin2;
                 return player.storage.nzry_guxin2===event.card;
             },
                        content:function(){
                 player.draw();
             },
                        onremove:(player,skill)=>player.removeGaintag(skill),
                        sub:true,
                        "_priority":0,
                    },
                    "tag3":{
                        trigger:{
                            player:"useCardEnd",
                        },
                        filter:function(event,player){
                 // var evt=event.card;
                 // return evt.gaintag&&evt.gaintag.contains('nzry_guxin_tag3');
                 for(var i of event.card.cards) {
                     if (i.gaintag && i.gaintag.contains('nzry_guxin_tag3'))
                         return true;
                 }
             },
                        content:function() {
                 if (player.canMoveCard()) {
                     var choiceList = [];
                     choiceList.push('移动场上的一张牌');
                     player.chooseControl('cancel2').set('choiceList', choiceList).set('prompt', get.prompt('nzry_guxin_2'));
                 }
             },
                        sub:true,
                        "_priority":0,
                    },
                    draw:{
                        trigger:{
                            player:"useCard",
                        },
                        frequent:true,
                        filter:function(event,player){
                 var color1=player.storage.nzry_guxin1[0];
                 var color2=get.color(event.card);
                 return color1&&color2&&color1!='none'&&color2!='none'&&color1===color2;
             },
                        content:function(){
                 player.draw();
             },
                        onremove:true,
                        sub:true,
                        "_priority":0,
                    },
                },
                "_priority":0,
            },
            lyyuheng:{
                trigger:{
                    player:"phaseUseBegin",
                },
                filter:function(event,player){
        return true;
    },
                frequent:true,
                content:function(){
        'step 0'
        player.judge();
        'step 1'
        player.addToExpansion(result.card,'gain2').gaintag.add('lyyuheng');
        'step 2'
        var card=result.card;
        player.addTempSkill('lyyuheng_1');
        player.storage.lyyuheng_1=get.number(card);
        player.storage.lyyuheng_2=get.type2(card);
        player.storage.lyyuheng_3=get.name(card);
        player.addTempSkill('lyyuheng_2');
    },
                onremove:function(player,skill){
        var cards=player.getExpansions(skill);
        if(cards.length) player.loseToDiscardpile(cards);
    },
                intro:{
                    content:"expansion",
                    markcount:"expansion",
                },
                marktext:"衡",
                subSkill:{
                    "1":{
                        onremove:true,
                        trigger:{
                            player:"useCard",
                        },
                        forced:true,
                        charlotte:true,
                        filter:function(event,player){
                return get.type2(event.card)==player.storage.lyyuheng_2||get.number(event.card)==player.storage.lyyuheng_1||get.name(event.card)==player.storage.lyyuheng_3;
            },
                        content:function(){
                if(get.type2(trigger.card)==player.storage.lyyuheng_2)
                    player.draw();
                if (get.number(trigger.card)==player.storage.lyyuheng_1)
                    player.draw(2);
                if(get.name(trigger.card)==player.storage.lyyuheng_3){
                    trigger.directHit.addArray(game.filterPlayer(function(current){
                     return current!=player;
                 }));
                //     player.draw();
                }
            },
                        sub:true,
                        "_priority":0,
                    },
                    "2":{
                        trigger:{
                            player:"phaseJieshuBegin",
                        },
                        forced:true,
                        content:function() {
                var cards = player.getExpansions('lyyuheng');
                if (cards.length)
                    player.loseToDiscardpile(cards);
                delete player.storage.lyyuheng_1;
                delete player.storage.lyyuheng_2;
                delete player.storage.lyyuheng_3;
            },
                        sub:true,
                        "_priority":0,
                    },
                    "11":{
                        onremove:true,
                        trigger:{
                            player:"useCard",
                        },
                        forced:true,
                        charlotte:true,
                        filter:function(event,player){
                return get.type2(event.card)==player.storage.lyyuheng_22||get.number(event.card)==player.storage.lyyuheng_11||get.name(event.card)==player.storage.lyyuheng_33;
            },
                        content:function(){
                if(get.type2(trigger.card)==player.storage.lyyuheng_22)
                    player.draw();
                if (get.number(trigger.card)==player.storage.lyyuheng_11)
                    player.draw(2);
                if(get.name(trigger.card)==player.storage.lyyuheng_33){
                    trigger.directHit.addArray(game.filterPlayer(function(current){
                        return current!=player;
                    }));
                    //     player.draw();
                }
            },
                        sub:true,
                        "_priority":0,
                    },
                },
                "_priority":0,
            },
            lyleili:{
                unique:true,
                limited:true,
                mark:true,
                intro:{
                    content:"limited",
                },
                skillAnimation:true,
                init:function (player) {//初始化
        player.storage.lyleili = false;//技能未发动(xx为技能名)
    },
                filter:function (event, player) {//发动限制条件
        return player.storage.lyleili == false;//你没发动过这个技能
    },
                enable:"phaseUse",
                content:function () {//内容:
        "step 0"//第0步
        player.storage.lyleili = true;//技能发动过
        player.awakenSkill("lyleili");//技能文本变灰(失去技能，标记消失)
        "step 1"//第1步
        player.judge();
        'step 1'
        player.addToExpansion(result.card,player,'give').gaintag.add('lyleili1');
        'step 2'
        var card=result.card;
        player.addTempSkill('lyyuheng_11');
        player.storage.lyyuheng_11=get.number(card);
        player.storage.lyyuheng_22=get.type2(card);
        player.storage.lyyuheng_33=get.name(card);
    },
                "_priority":0,
            },
            "lyleili1":{
                intro:{
                    content:"expansion",
                },
                "_priority":0,
            },
            yuhenggai:{
                trigger:{
                    player:"phaseUseBegin",
                },
                filter:function(event,player){
        return true;
    },
                frequent:true,
                init:function(player){//初始化，获得这个技能时执行的内容
        player.storage.yuhenggai=[];
    },
                content:function(){
        'step 0'
        player.judge();
        'step 1'
        player.addToExpansion(result.card,'gain2').gaintag.add('lyyuheng');
        'step 2'
        var card=result.card;
        player.addTempSkill('yuhenggai_1');
        player.storage.lyyuheng_1=get.number(card);
        player.storage.lyyuheng_2=get.suit(card);
        player.storage.lyyuheng_3=get.color(card);
        player.storage.lyyuheng_4=get.type(card);
        player.storage.lyyuheng_5=get.name(card);
        player.addTempSkill('yuhenggai_2');
    },
                onremove:function(player,skill){
        var cards=player.getExpansions(skill);
        if(cards.length) player.loseToDiscardpile(cards);
    },
                intro:{
                    content:"expansion",
                    markcount:"expansion",
                },
                marktext:"衡",
                subSkill:{
                    "1":{
                        onremove:true,
                        trigger:{
                            player:"useCard",
                        },
                        forced:true,
                        charlotte:true,
                        filter:function(event,player){
                return get.number(event.card)==player.storage.lyyuheng_1||get.suit(event.card)==player.storage.lyyuheng_2||get.color(event.card)==player.storage.lyyuheng_3
                get.type2(event.card)==player.storage.lyyuheng_4||get.name(event.card)==player.storage.lyyuheng_5;
            },
                        content:function(){
                if(get.number(trigger.card)==player.storage.lyyuheng_1) {
                    player.draw(5).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
                if (get.suit(trigger.card)==player.storage.lyyuheng_2){
                    player.draw(4).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

            }
                if(get.color(trigger.card)==player.storage.lyyuheng_3){
                    player.draw(3).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

}
                if(get.type(trigger.card)==player.storage.lyyuheng_4){
                    player.draw(2).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

}
                if(get.name(trigger.card)==player.storage.lyyuheng_5){
                    player.draw(1).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

}
            },
                        sub:true,
                        "_priority":0,
                    },
                    "2":{
                        trigger:{
                            player:"phaseJieshuBegin",
                        },
                        forced:true,
                        content:function() {
                var cards = player.getExpansions('lyyuheng');
                if (cards.length)
                    player.loseToDiscardpile(cards);
                delete player.storage.lyyuheng_1;
                delete player.storage.lyyuheng_2;
                delete player.storage.lyyuheng_3;
            },
                        sub:true,
                        "_priority":0,
                    },
                    "11":{
                        onremove:true,
                        trigger:{
                            player:"useCard",
                        },
                        forced:true,
                        charlotte:true,
                        filter:function(event,player){
                return get.number(event.card)==player.storage.lyyuheng_11||get.suit(event.card)==player.storage.lyyuheng_22||get.color(event.card)==player.storage.lyyuheng_33
                get.type2(event.card)==player.storage.lyyuheng_44||get.name(event.card)==player.storage.lyyuheng_55;
            },
                        content:function(){
                if(get.number(trigger.card)==player.storage.lyyuheng_11) {
                    player.draw(5).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
                if (get.suit(trigger.card)==player.storage.lyyuheng_22){
                    player.draw(4).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
                if(get.color(trigger.card)==player.storage.lyyuheng_33){
                    player.draw(3).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
                if(get.type(trigger.card)==player.storage.lyyuheng_44){
                    player.draw(2).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
                if(get.name(trigger.card)==player.storage.lyyuheng_55){
                    player.draw(1).gaintag=['yuhenggai_tag'];player.addTempSkill('yuhenggai_tag');
                            

                }
            },
                        sub:true,
                        "_priority":0,
                    },
                    tag:{
                        mod:{
                            ignoredHandcard:function(card,player){
                    if(card.gaintag&&card.gaintag.contains('yuhenggai_tag'))
                        return true;
                },
                            cardUsable:function(card){
                    // if(card.gaintag&&card.gaintag.contains('yuhenggai_tag'))
                    for(var i of card.cards) {
                        if (i.gaintag && i.gaintag.contains('yuhenggai_tag'))
                            return Infinity;
                    }
                },
                        },
                        onremove:(player,skill)=>player.removeGaintag(skill),
                        sub:true,
                        "_priority":0,
                    },
                },
                "_priority":0,
            },
            leiligai:{
                unique:true,
                limited:true,
                mark:true,
                intro:{
                    content:"limited",
                },
                skillAnimation:true,
                init:function (player) {//初始化
        player.storage.lyleili = false;//技能未发动(xx为技能名)
    },
                filter:function (event, player) {//发动限制条件
        return player.storage.lyleili == false;//你没发动过这个技能
    },
                enable:"phaseUse",
                content:function () {//内容:
        "step 0"//第0步
        player.storage.lyleili = true;//技能发动过
        player.awakenSkill("lyleili");//技能文本变灰(失去技能，标记消失)
        "step 1"//第1步
        player.judge();
        'step 1'
        player.addToExpansion(result.card,'gain2').gaintag.add('lyleili1');
        'step 2'
        var card=result.card;
        player.addTempSkill('lyyuheng_11');
        player.storage.lyyuheng_11=get.number(card);
        player.storage.lyyuheng_22=get.suit(card);
        player.storage.lyyuheng_33=get.color(card);
        player.storage.lyyuheng_44=get.type2(card);
        player.storage.lyyuheng_55=get.name(card);
    },
                "_priority":0,
            },
            shuangsheng:{
                trigger:{
                    player:["phaseBefore","turnOverAfter"],
                },
                forced:true,
                popup:false,
                init:function(player){
        if(game.online) return;

            if(player.classList.contains('turnedover'))

        player.removeAdditionalSkill('shuangsheng');
        var list=[];
        if(player.classList.contains('turnedover')){
            list.push('xiaoji');
        }
        if(!player.classList.contains('turnedover')){
            list.push('qiuyuan');
        }
        if(list.length){
            player.addAdditionalSkill('shuangsheng',list);
        }
    },
                derivation:["xiaoji","qiuyuan"],
                content:function(){
        player.removeAdditionalSkill('shuangsheng');
        var list=[];
            if(player.classList.contains('turnedover')){
                list.push('xiaoji');
            }
            if(!player.classList.contains('turnedover')){
                list.push('qiuyuan');
            }
            if(list.length){
                player.addAdditionalSkill('shuangsheng',list);
            }
    },
                "_priority":0,
            },
            xmrumeng:{
                init:function(player){
        player.storage.xmrumeng=0;
        player.storage.xmrumeng1=2;
    },
                mark:true,
                intro:{
                    content:"已发动过#次",
                },
                trigger:{
                    player:["phaseJieshuBegin","damageEnd"],
                },
                filter:function(event,player){
        return true;
    },
                content:function() {
        'step 0'
        player.draw(Math.min(player.storage.xmrumeng,player.storage.xmrumeng1));
        player.turnOver();
        'step 1'
        player.storage.xmrumeng++;
        if (!player.isMaxHandcard(true) && player.canMoveCard()) {
            var choiceList = [];
            choiceList.push('移动场上的一张牌');
            player.chooseControl('cancel2').set('choiceList', choiceList).set('prompt', get.prompt('xmrumeng'));
        }else event.finish();
        'step 2'
        if (result.control == 'cancel2')
            event.finish();
        else player.moveCard(true);
    },
                "_priority":0,
            },
            mengxing:{
                group:["mengxing_1","mengxing_2"],
                subSkill:{
                    "1":{
                        trigger:{
                            global:"phaseEnd",
                        },
                        forced:true,
                        juexingji:true,
                        skillAnimation:true,
                        animationColor:"gray",
                        filter:function(event,player){
                return player.storage.xmrumeng>=2;
            },
                        content:function(){
                'step 0'
                player.awakenSkill('mengxing_1');
                'step 1'
                player.storage.xmrumeng1=4;
                player.gainMaxHp();
                'step 2'
                player.addSkill('mengxing_zhengmianxiaoji');

            },
                        sub:true,
                        "_priority":0,
                    },
                    "2":{
                        trigger:{
                            global:"phaseEnd",
                        },
                        forced:true,
                        juexingji:true,
                        skillAnimation:true,
                        animationColor:"gray",
                        filter:function(event,player){
                return player.storage.xmrumeng>=4;
            },
                        content:function(){
                'step 0'
                player.awakenSkill('mengxing_2');
                'step 1'
                player.addSkill('dczhanmeng');
                player.gainMaxHp();
            },
                        sub:true,
                        "_priority":0,
                    },
                    zhengmianxiaoji:{
                        trigger:{
                            player:["phaseBefore","turnOverAfter"],
                        },
                        forced:true,
                        popup:false,
                        init:function(player){
                if(game.online) return;
                if(player.classList.contains('turnedover'))
                    player.removeAdditionalSkill('mengxing_zhengmianxiaoji');
                var list=[];
                if(!player.classList.contains('turnedover')){
                    list.push('xiaoji');
                }
                if(list.length){
                    player.addAdditionalSkill('mengxing_zhengmianxiaoji',list);
                }
            },
                        derivation:["xiaoji"],
                        content:function(){
                player.removeAdditionalSkill('mengxing_zhengmianxiaoji');
                var list=[];
                if(!player.classList.contains('turnedover')){
                    list.push('xiaoji');
                }
                if(list.length){
                    player.addAdditionalSkill('mengxing_zhengmianxiaoji',list);
                }
            },
                        sub:true,
                        "_priority":0,
                    },
                },
                "_priority":0,
            },
            lyfangshi:{
                group:["lyfangshi_1","lyfangshi_2"],
                subSkill:{
                    "1":{
                        usable:1,
                        trigger:{
                            player:"gainAfter",
                        },
                        filter:function(event,player,card){
                return true;
            },
                        content:function(){
                'step 0'
                if(get.color(trigger.card)=='red')
                     player.draw();
                else event.finish();
                'step 1'
                player.addSkill(lyfangshi_jiashang);
            },
                        sub:true,
                        "_priority":0,
                    },
                    "2":{
                        usable:1,
                        trigger:{
                            player:"gainAfter",
                        },
                        filter:function(event,player,card){
                return true;
            },
                        content:function(){
                'step 0'
                if(get.color(trigger.card)=='black')
                        player.discard(trigger.card);
                else event.finish();
                'step 1'
                player.chooseUseTarget({name: 'sha',  nature: 'ice',},true,false,'nodistance');
            },
                        sub:true,
                        "_priority":0,
                    },
                    jiashang:{
                        mark:true,
                        marktext:"烈",
                        nopop:true,
                        intro:{
                            content:"下一次造成的伤害+1",
                        },
                        logv:false,
                        trigger:{
                            source:"damageBegin",
                        },
                        forced:true,
                        content:function(){
                trigger.num++;
                player.removeSkill('lyfangshi_jiashang');
            },
                        sub:true,
                        "_priority":0,
                    },
                },
                "_priority":0,
            },
        },
        translate:{
            "蝶引":"蝶引",
            "蝶引_info":"弃牌阶段开始时，或当你受到1点伤害后，你可以摸两张牌，然后将一张红色牌置于武将牌上（无则不放），称为“舞”；",
            "安神":"安神",
            "安神_info":"一名其他角色的出牌阶段开始时若你的体力值不多于“舞”，你可以将张“舞”当“火杀”对其使用。若以此法造成了伤害，你回复一点体力。",
            "行侠":"行侠",
            "行侠_info":"当你受到一点伤害后，你可以展示伤害来源的一张手牌，然后将其交给任意一名角色",
            "惩恶":"惩恶",
            "惩恶_info":"一名其他角色的回合结束时，若其于本回合内造成过伤害，则你可以将一张手牌当“杀”或“过河拆桥”对其使用",
            "nzry_guxin":"孤心",
            "nzry_guxin_info":"出牌阶段限一次，阴:失去一点体力(最多失去至1点)然后展示牌堆顶的三张牌，你获得其中一张，根据其类型获得效果:基本:此牌伤害/回复量+1。锦囊:此牌无距离限制且不可被响应 装备:使用此牌后移动场上的一张牌。阳:回复一点体力(若体力满则改为摸两张牌)并弃一张牌，本回合内你使用与其颜色相同的牌时摸一张牌。",
            lyyuheng:"玉衡",
            "lyyuheng_info":"出牌阶段开始时，你可以进行一次判定并将判定牌置于你的武将牌上，称之为“衡”，你使用牌指定目标时，其每与一张“衡”点数/类型/牌名相同，你摸两张牌/摸一张牌/使该牌无法被响应；结束阶段开始时，移除所有“衡。",
            lyleili:"雷厉",
            "lyleili_info":"限定技，出牌阶段限一次，你可以额外进行一次“玉衡”的判定。",
            "lyleili1":"lyleili1",
            "lyleili1_info":"lyleili1",
            yuhenggai:"玉衡",
            "yuhenggai_info":"出牌阶段开始时，你可以进行一次判定并将判定牌置于你的武将牌上，称之为“衡”。若如此做，本回合你使用牌指定目标时，其每与一张“衡”点数/花色/颜色/类型/牌名相同，你摸五张牌/摸四张牌/摸三张牌/摸二张牌/摸一张牌，你使用以此法获得的牌无次数限制，以此法获得的牌本回合不计入手牌上限；结束阶段开始时，移除所有“衡”。",
            leiligai:"雷厉",
            "leiligai_info":"限定技，出牌阶段限一次，你可以额外进行一次“玉衡”的判定。",
            shuangsheng:"双生",
            "shuangsheng_info":"锁定技，你的武将牌正面向上时，你视为拥有“求援”，背面向上时，你视为拥有“枭姬”。",
            xmrumeng:"入梦",
            "xmrumeng_info":"结束阶段或当你受到伤害后 你可以翻至背面并摸x张牌（x为你本局游戏发动过“入梦”的次数且至多为2），若此时你的手牌不为全场唯一最多，你可以移动场上的一张牌。",
            mengxing:"梦醒",
            "mengxing_info":"每个回合结束后，若你本局游戏发动过“入梦”的次数不少于2，修改”双生“”入梦“；若你本局游戏发动过“入梦”的次数不少于4，你获得”占梦“。",
            lyfangshi:"方士",
            "lyfangshi_info":"每回合每种颜色限一次，当你获得一张牌后，若此牌颜色为红色，你可以摸一张牌并令你下一次造成的伤害加一；若此牌颜色为黑色，你可以弃置此牌并视为使用一张不计入次数且无距离限制的冰杀；",
        },
    },
    intro:"",
    author:"无名玩家",
    diskURL:"",
    forumURL:"",
    version:"1.0",
},files:{"character":["行秋.jpg","刻晴.jpg","重云.jpg","芙宁娜.jpg","胡桃.jpg","莱依拉.jpg"],"card":[],"skill":[],"audio":[]}}})